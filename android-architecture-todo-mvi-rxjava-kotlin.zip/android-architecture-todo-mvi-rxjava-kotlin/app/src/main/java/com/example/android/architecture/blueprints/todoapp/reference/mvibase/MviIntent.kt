package com.example.android.architecture.blueprints.todoapp.reference.mvibase

/**
 * Immutable object which represent an view's intent.
 */
interface MviIntent
