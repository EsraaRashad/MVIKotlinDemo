package com.example.android.architecture.blueprints.todoapp.football.data.model

// Api url :
//https://raw.githubusercontent.com/openfootball/football.json/master/2015-16/en.1.json