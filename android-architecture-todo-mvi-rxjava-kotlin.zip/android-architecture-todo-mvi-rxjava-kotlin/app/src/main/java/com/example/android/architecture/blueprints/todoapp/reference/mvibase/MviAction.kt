package com.example.android.architecture.blueprints.todoapp.reference.mvibase

/**
 * Immutable object which contains all the required information for a business logic to process.
 */
interface MviAction
