package com.example.android.architecture.blueprints.todoapp.football.data.model

data class Round(
        val matches: List<Match>,
        val name: String
)