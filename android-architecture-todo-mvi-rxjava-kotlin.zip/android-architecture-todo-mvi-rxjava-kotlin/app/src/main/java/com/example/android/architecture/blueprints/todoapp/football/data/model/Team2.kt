package com.example.android.architecture.blueprints.todoapp.football.data.model

data class Team2(
    val code: String,
    val key: String,
    val name: String
)