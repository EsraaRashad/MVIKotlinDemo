package com.example.android.architecture.blueprints.todoapp.football.di.helper

object AppInjector {
}