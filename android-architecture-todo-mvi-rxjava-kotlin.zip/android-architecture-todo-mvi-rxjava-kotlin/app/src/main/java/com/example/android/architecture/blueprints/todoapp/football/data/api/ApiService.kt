package com.example.android.architecture.blueprints.todoapp.football.data.api

interface ApiService {
}