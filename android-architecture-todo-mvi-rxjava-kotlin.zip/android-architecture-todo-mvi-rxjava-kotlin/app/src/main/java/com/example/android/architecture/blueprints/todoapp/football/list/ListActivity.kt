package com.example.android.architecture.blueprints.todoapp.football.list

import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import com.example.android.architecture.blueprints.todoapp.R

class ListActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_statistics)
    }
}
