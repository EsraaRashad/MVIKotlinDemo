package com.example.android.architecture.blueprints.todoapp.football.mvibase

interface MviResultFB {
}