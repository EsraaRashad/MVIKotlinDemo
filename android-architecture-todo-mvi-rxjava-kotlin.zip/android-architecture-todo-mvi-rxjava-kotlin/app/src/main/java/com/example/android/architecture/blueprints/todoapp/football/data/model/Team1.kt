package com.example.android.architecture.blueprints.todoapp.football.data.model

data class Team1(
    val code: String,
    val key: String,
    val name: String
)