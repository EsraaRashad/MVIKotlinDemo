package com.example.android.architecture.blueprints.todoapp.reference.mvibase

/**
 * Immutable object resulting of a processed business logic.
 */
interface MviResult
