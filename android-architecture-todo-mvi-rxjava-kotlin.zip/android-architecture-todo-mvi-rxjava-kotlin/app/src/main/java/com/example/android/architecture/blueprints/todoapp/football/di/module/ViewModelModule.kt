package com.example.android.architecture.blueprints.todoapp.football.di.module

abstract class ViewModelModule {
}